import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

sns.set_theme(style="whitegrid")
plt.rcParams.update(
    {
        "figure.figsize": (9, 5),
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
    }
)

OUTCOME_ORDER = ["Dropout", "Enrolled", "Graduate"]
OUTCOME_PALETTE = {"Dropout": "#9b4141", "Enrolled": "#b8b8b8", "Graduate": "#298c8c"}
BAR_COLOR = "#0072B2"
DROPOUT_COLOR = "#9b4141"

os.makedirs("figures", exist_ok=True)

ORDER = {
    "Target": OUTCOME_ORDER,
    "Gender": ["Female", "Male"],
    "Displaced": ["No", "Yes"],
    "Debtor": ["No", "Yes"],
    "Tuition_Up_To_Date": ["No", "Yes"],
    "Scholarship_Holder": ["No", "Yes"],
    "Daytime_Evening": ["Daytime", "Evening"],
    "Marital_Group": ["Single", "Not single"],
    "Age_Group": ["17-19", "20-24", "25-29", "30+"],
    "Admission_Grade_Band": ["Q1 (lowest)", "Q2", "Q3", "Q4 (highest)"],
    "Parent_Education": ["Basic", "Secondary", "Higher", "Unknown"],
    "Application_Order_Group": ["0-1", "2", "3+"],
    "Application_Mode_Group": [
        "General contingent",
        "Over 23 years old",
        "Transfer or change",
        "Prior diploma holder",
        "Special or other",
    ],
    "Passed_None_1st": ["No", "Yes"],
    "Passed_None_2nd": ["No", "Yes"],
}


def apply_order(df):
    df = df.copy()
    for col, cats in ORDER.items():
        if col in df.columns:
            df[col] = pd.Categorical(df[col], categories=cats, ordered=True)
    return df

df = pd.read_csv("student_dropout_cleaned.csv")

# Apply categorical ordering
df = apply_order(df)

print("Dataset loaded successfully.")
print("Dataset shape:", df.shape)

# Check required columns
required_columns = ["Admission_Grade", "Target"]

for col in required_columns:
    if col not in df.columns:
        raise ValueError(f"Missing required column: {col}")

# Select relevant variables
c1 = df[required_columns].copy()

# Check missing values
print("Missing values:")
print(c1.isnull().sum())

# Check Target distribution
print("\nTarget distribution:")
print(c1["Target"].value_counts())

print("\nTarget percentages:")
print(
    c1["Target"].value_counts(normalize=True).mul(100).round(2)
)

# Descriptive statistics
print("\nAdmission grade descriptive statistics:")
print(c1["Admission_Grade"].describe())


# Remove missing observations
c1 = c1.dropna(
    subset=["Admission_Grade", "Target"]
).copy()

# Ensure admission grade is numeric
c1["Admission_Grade"] = pd.to_numeric(
    c1["Admission_Grade"],
    errors="coerce"
)

c1 = c1.dropna(
    subset=["Admission_Grade"]
).copy()

# Create binary dropout variable
c1["Dropout_Binary"] = (
    c1["Target"] == "Dropout"
).astype(int)

# Create admission grade quartiles
c1["Admission_Grade_Band"] = pd.qcut(
    c1["Admission_Grade"],
    q=4,
    labels=ORDER["Admission_Grade_Band"]
)

print("Final C1 dataset shape:", c1.shape)

print("\nAdmission grade quartiles:")
print(
    c1.groupby(
        "Admission_Grade_Band",
        observed=True
    )["Admission_Grade"].agg(
        ["min", "max", "mean", "count"]
    )
)


# Descriptive statistics by outcome
c1_summary = (
    c1.groupby("Target", observed=True)["Admission_Grade"]
    .agg(["count", "mean", "median", "std", "min", "max"])
    .reindex(OUTCOME_ORDER)
)

print(c1_summary.round(2))


plt.figure(figsize=(9, 5))

sns.boxplot(
    data=c1,
    x="Target",
    y="Admission_Grade",
    order=OUTCOME_ORDER,
    hue="Target",
    hue_order=OUTCOME_ORDER,
    palette=OUTCOME_PALETTE,
    legend=False,
    notch = True
)

plt.title("Admission Grade by Student Outcome")
plt.xlabel("Student outcome")
plt.ylabel("Admission grade")
plt.tight_layout()

'''plt.savefig(
    "figures/C1_admission_grade_boxplot.png",
    dpi=300,
    bbox_inches="tight"
)'''

plt.show()


# Calculate dropout rate by quartile
dropout_by_quartile = (
    c1.groupby(
        "Admission_Grade_Band",
        observed=True
    )["Dropout_Binary"]
    .agg(["mean", "count", "sum"])
)

dropout_by_quartile["Dropout_Rate"] = (
    dropout_by_quartile["mean"] * 100
)

print(dropout_by_quartile.round(2))




plt.figure(figsize=(9, 5))

sns.barplot(
    data=c1,
    x="Admission_Grade_Band",
    y="Dropout_Binary",
    order=ORDER["Admission_Grade_Band"],
    color=DROPOUT_COLOR,
    errorbar=None
)

plt.title("Dropout Rate by Admission Grade Quartile")
plt.xlabel("Admission grade quartile")
plt.ylabel("Dropout rate")
plt.gca().yaxis.set_major_formatter(
    plt.FuncFormatter(lambda y, _: f"{y:.0%}")
)

plt.ylim(0, 1)
plt.tight_layout()

'''plt.savefig(
    "figures/C1_dropout_rate_by_quartile.png",
    dpi=300,
    bbox_inches="tight"
)'''

plt.show()



# Extract admission grades for each outcome
groups = [
    c1.loc[
        c1["Target"] == outcome,
        "Admission_Grade"
    ].values
    for outcome in OUTCOME_ORDER
]

# Kruskal-Wallis test
kw_stat, kw_pvalue = stats.kruskal(*groups)

print("Kruskal-Wallis test")
print("-------------------")
print(f"H statistic: {kw_stat:.4f}")
print(f"P-value: {kw_pvalue:.6f}")

if kw_pvalue < 0.05:
    print("Result: Statistically significant differences.")
else:
    print("Result: No statistically significant differences.")

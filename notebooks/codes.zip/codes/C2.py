import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

sns.set_theme(style="whitegrid")
plt.rcParams.update(
    {
        "figure.figsize": (9, 5),
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
    }
)

OUTCOME_ORDER = ["Dropout", "Enrolled", "Graduate"]
OUTCOME_PALETTE = {"Dropout": "#9b4141", "Enrolled": "#b8b8b8", "Graduate": "#298c8c"}
BAR_COLOR = "#0072B2"
DROPOUT_COLOR = "#9b4141"

os.makedirs("figures", exist_ok=True)

ORDER = {
    "Target": OUTCOME_ORDER,
    "Gender": ["Female", "Male"],
    "Displaced": ["No", "Yes"],
    "Debtor": ["No", "Yes"],
    "Tuition_Up_To_Date": ["No", "Yes"],
    "Scholarship_Holder": ["No", "Yes"],
    "Daytime_Evening": ["Daytime", "Evening"],
    "Marital_Group": ["Single", "Not single"],
    "Age_Group": ["17-19", "20-24", "25-29", "30+"],
    "Admission_Grade_Band": ["Q1 (lowest)", "Q2", "Q3", "Q4 (highest)"],
    "Parent_Education": ["Basic", "Secondary", "Higher", "Unknown"],
    "Application_Order_Group": ["0-1", "2", "3+"],
    "Application_Mode_Group": [
        "General contingent",
        "Over 23 years old",
        "Transfer or change",
        "Prior diploma holder",
        "Special or other",
    ],
    "Passed_None_1st": ["No", "Yes"],
    "Passed_None_2nd": ["No", "Yes"],
}


def apply_order(df):
    df = df.copy()
    for col, cats in ORDER.items():
        if col in df.columns:
            df[col] = pd.Categorical(df[col], categories=cats, ordered=True)
    return df


df = pd.read_csv("student_dropout_cleaned.csv")

# Apply categorical ordering
df = apply_order(df)


# Select variables for C2
c2 = df[
    ["Prev_Qual_Grade", "Target"]
].copy()

# Convert previous qualification grade to numeric
c2["Prev_Qual_Grade"] = pd.to_numeric(
    c2["Prev_Qual_Grade"],
    errors="coerce"
)

# Remove missing observations
c2 = c2.dropna(
    subset=["Prev_Qual_Grade", "Target"]
).copy()

# Check dataset
print("C2 dataset shape:", c2.shape)

print("\nMissing values:")
print(c2.isnull().sum())

print("\nTarget distribution:")
print(c2["Target"].value_counts())



# Descriptive statistics by outcome
c2_summary = (
    c2.groupby("Target", observed=True)
    ["Prev_Qual_Grade"]
    .agg(["count", "mean", "median", "std", "min", "max"])
    .reindex(OUTCOME_ORDER)
)

print(c2_summary.round(2))



plt.figure(figsize=(9, 5))

sns.boxplot(
    data=c2,
    x="Target",
    y="Prev_Qual_Grade",
    order=OUTCOME_ORDER,
    hue="Target",
    hue_order=OUTCOME_ORDER,
    palette=OUTCOME_PALETTE,
    legend=False,
    notch = True
)

plt.title("Previous Qualification Grade by Student Outcome")
plt.xlabel("Student outcome")
plt.ylabel("Previous qualification grade")

plt.tight_layout()

'''plt.savefig(
    "figures/C2_previous_qualification_boxplot.png",
    dpi=300,
    bbox_inches="tight"
)'''

plt.show()


# Extract grades for each outcome
groups_c2 = [
    c2.loc[
        c2["Target"] == outcome,
        "Prev_Qual_Grade"
    ].values
    for outcome in OUTCOME_ORDER
]

# Kruskal-Wallis test
kw_stat_c2, kw_pvalue_c2 = stats.kruskal(
    *groups_c2
)

print("Kruskal-Wallis test - C2")
print("-------------------------")
print(f"H statistic: {kw_stat_c2:.4f}")
print(f"P-value: {kw_pvalue_c2:.6f}")

if kw_pvalue_c2 < 0.05:
    print("Result: Statistically significant differences.")
else:
    print("Result: No statistically significant differences.")

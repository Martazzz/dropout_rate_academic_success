import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

sns.set_theme(style="whitegrid")
plt.rcParams.update(
    {
        "figure.figsize": (9, 5),
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
    }
)

OUTCOME_ORDER = ["Dropout", "Enrolled", "Graduate"]
OUTCOME_PALETTE = {"Dropout": "#9b4141", "Enrolled": "#b8b8b8", "Graduate": "#298c8c"}
BAR_COLOR = "#0072B2"
DROPOUT_COLOR = "#9b4141"

os.makedirs("figures", exist_ok=True)

ORDER = {
    "Target": OUTCOME_ORDER,
    "Gender": ["Female", "Male"],
    "Displaced": ["No", "Yes"],
    "Debtor": ["No", "Yes"],
    "Tuition_Up_To_Date": ["No", "Yes"],
    "Scholarship_Holder": ["No", "Yes"],
    "Daytime_Evening": ["Daytime", "Evening"],
    "Marital_Group": ["Single", "Not single"],
    "Age_Group": ["17-19", "20-24", "25-29", "30+"],
    "Admission_Grade_Band": ["Q1 (lowest)", "Q2", "Q3", "Q4 (highest)"],
    "Parent_Education": ["Basic", "Secondary", "Higher", "Unknown"],
    "Application_Order_Group": ["0-1", "2", "3+"],
    "Application_Mode_Group": [
        "General contingent",
        "Over 23 years old",
        "Transfer or change",
        "Prior diploma holder",
        "Special or other",
    ],
    "Passed_None_1st": ["No", "Yes"],
    "Passed_None_2nd": ["No", "Yes"],
}


def apply_order(df):
    df = df.copy()
    for col, cats in ORDER.items():
        if col in df.columns:
            df[col] = pd.Categorical(df[col], categories=cats, ordered=True)
    return df


df = pd.read_csv("student_dropout_cleaned.csv")

# Apply categorical ordering
df = apply_order(df)


# Select variables for C3
c3 = df[
    ["Application_Order_Group", "Dropout_Binary", "Target"]
].copy()

# Remove missing values
c3 = c3.dropna(
    subset=["Application_Order_Group", "Dropout_Binary"]
).copy()

# Apply categorical ordering
c3["Application_Order_Group"] = pd.Categorical(
    c3["Application_Order_Group"],
    categories=ORDER["Application_Order_Group"],
    ordered=True
)

# Check dataset
print("C3 dataset shape:", c3.shape)

print("\nApplication order distribution:")
print(c3["Application_Order_Group"].value_counts().sort_index())

print("\nDropout distribution:")
print(c3["Dropout_Binary"].value_counts())


c3_summary = (
    c3.groupby("Application_Order_Group", observed=True)
    .agg(
        Total_Students=("Dropout_Binary", "count"),
        Dropouts=("Dropout_Binary", "sum"),
        Dropout_Rate=("Dropout_Binary", "mean")
    )
)

c3_summary["Dropout_Rate"] *= 100

print(c3_summary.round(2))



plt.figure(figsize=(9, 5))

sns.barplot(
    data=c3,
    x="Application_Order_Group",
    y="Dropout_Binary",
    order=ORDER["Application_Order_Group"],
    color=DROPOUT_COLOR,
    errorbar=None
)

plt.title("Dropout Rate by Application Order")
plt.xlabel("Application order")
plt.ylabel("Dropout rate")

plt.gca().yaxis.set_major_formatter(
    plt.FuncFormatter(lambda y, _: f"{y:.0%}")
)

plt.ylim(0, 1)
plt.tight_layout()

'''plt.savefig(
    "figures/C3_dropout_rate_by_application_order.png",
    dpi=300,
    bbox_inches="tight"
)'''

plt.show()



contingency_c3 = pd.crosstab(
    c3["Application_Order_Group"],
    c3["Dropout_Binary"]
)

contingency_c3.columns = ["Non-Dropout", "Dropout"]

print("Contingency table:")
print(contingency_c3)




chi2_c3, p_c3, dof_c3, expected_c3 = stats.chi2_contingency(
    contingency_c3
)

print("Chi-square test - C3")
print("---------------------")
print(f"Chi-square statistic: {chi2_c3:.4f}")
print(f"Degrees of freedom: {dof_c3}")
print(f"P-value: {p_c3:.6f}")

if p_c3 < 0.05:
    print("Result: Statistically significant association.")
else:
    print("Result: No statistically significant association.")

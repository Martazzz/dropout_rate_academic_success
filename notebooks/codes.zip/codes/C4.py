import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

sns.set_theme(style="whitegrid")
plt.rcParams.update(
    {
        "figure.figsize": (9, 5),
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
    }
)

OUTCOME_ORDER = ["Dropout", "Enrolled", "Graduate"]
OUTCOME_PALETTE = {"Dropout": "#9b4141", "Enrolled": "#b8b8b8", "Graduate": "#298c8c"}
BAR_COLOR = "#0072B2"
DROPOUT_COLOR = "#9b4141"

os.makedirs("figures", exist_ok=True)

ORDER = {
    "Target": OUTCOME_ORDER,
    "Gender": ["Female", "Male"],
    "Displaced": ["No", "Yes"],
    "Debtor": ["No", "Yes"],
    "Tuition_Up_To_Date": ["No", "Yes"],
    "Scholarship_Holder": ["No", "Yes"],
    "Daytime_Evening": ["Daytime", "Evening"],
    "Marital_Group": ["Single", "Not single"],
    "Age_Group": ["17-19", "20-24", "25-29", "30+"],
    "Admission_Grade_Band": ["Q1 (lowest)", "Q2", "Q3", "Q4 (highest)"],
    "Parent_Education": ["Basic", "Secondary", "Higher", "Unknown"],
    "Application_Order_Group": ["0-1", "2", "3+"],
    "Application_Mode_Group": [
        "General contingent",
        "Over 23 years old",
        "Transfer or change",
        "Prior diploma holder",
        "Special or other",
    ],
    "Passed_None_1st": ["No", "Yes"],
    "Passed_None_2nd": ["No", "Yes"],
}


def apply_order(df):
    df = df.copy()
    for col, cats in ORDER.items():
        if col in df.columns:
            df[col] = pd.Categorical(df[col], categories=cats, ordered=True)
    return df


df = pd.read_csv("student_dropout_cleaned.csv")

# Apply categorical ordering
df = apply_order(df)



# Select variables for C4
c4 = df[
    ["Application_Mode_Group", "Target"]
].copy()

# Remove missing values
c4 = c4.dropna(
    subset=["Application_Mode_Group", "Target"]
).copy()

# Apply categorical ordering
c4["Application_Mode_Group"] = pd.Categorical(
    c4["Application_Mode_Group"],
    categories=ORDER["Application_Mode_Group"],
    ordered=True
)

c4["Target"] = pd.Categorical(
    c4["Target"],
    categories=OUTCOME_ORDER,
    ordered=True
)

# Check dataset
print("C4 dataset shape:", c4.shape)

print("\nApplication mode distribution:")
print(c4["Application_Mode_Group"].value_counts().sort_index())

print("\nTarget distribution:")
print(c4["Target"].value_counts().sort_index())


# Count students by application mode and outcome
c4_counts = pd.crosstab(
    c4["Application_Mode_Group"],
    c4["Target"]
)

print("Student distribution:")
print(c4_counts)


# Calculate percentages within each application mode
c4_percentages = pd.crosstab(
    c4["Application_Mode_Group"],
    c4["Target"],
    normalize="index"
) * 100

print("Outcome percentages by application mode:")
print(c4_percentages.round(2))


# Create binary dropout variable for C4
c4["Dropout_Binary"] = (
    c4["Target"] == "Dropout"
).astype(int)

# Calculate dropout rate by application mode
c4_dropout_rate = (
    c4.groupby(
        "Application_Mode_Group",
        observed=True
    )["Dropout_Binary"]
    .mean()
    .mul(100)
)

print("Dropout rate by application mode:")
print(c4_dropout_rate.round(2))




c4_summary = (
    df.groupby("Application_Mode_Group", observed=True)
    .agg(
        Total_Students=("Dropout_Binary", "count"),
        Dropouts=("Dropout_Binary", "sum"),
        Dropout_Rate=("Dropout_Binary", "mean")
    )
    .reset_index()
)

# Convert to percentage
c4_summary["Dropout_Rate"] *= 100

# Sort from highest to lowest
c4_summary = c4_summary.sort_values(
    "Dropout_Rate",
    ascending=True
)


plt.figure(figsize=(10, 6))

ax = sns.barplot(
    data=c4_summary,
    x="Dropout_Rate",
    y="Application_Mode_Group",
    color=BAR_COLOR
)

# Add percentage labels
for container in ax.containers:
    ax.bar_label(
        container,
        fmt="%.1f%%",
        padding=5
    )

plt.title("Dropout Rate by Application Mode")
plt.xlabel("Dropout Rate (%)")
plt.ylabel("Application Mode")

plt.xlim(
    0,
    c4_summary["Dropout_Rate"].max() * 1.15
)

plt.tight_layout()

'''plt.savefig(
    "figures/C4_horizontal_dropout_rate.png",
    dpi=300,
    bbox_inches="tight"
)'''

plt.show()


# Create contingency table
contingency_c4 = pd.crosstab(
    c4["Application_Mode_Group"],
    c4["Target"]
)

print("Contingency table:")
print(contingency_c4)

# Chi-square test
chi2_c4, p_c4, dof_c4, expected_c4 = stats.chi2_contingency(
    contingency_c4
)

print("\nChi-square test - C4")
print("---------------------")
print(f"Chi-square statistic: {chi2_c4:.4f}")
print(f"Degrees of freedom: {dof_c4}")
print(f"P-value: {p_c4:.6f}")

if p_c4 < 0.05:
    print("Result: Statistically significant association.")
else:
    print("Result: No statistically significant association.")

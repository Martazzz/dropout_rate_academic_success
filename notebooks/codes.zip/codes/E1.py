import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

sns.set_theme(style="whitegrid")
plt.rcParams.update(
    {
        "figure.figsize": (9, 5),
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
    }
)

OUTCOME_ORDER = ["Dropout", "Enrolled", "Graduate"]
OUTCOME_PALETTE = {"Dropout": "#9b4141", "Enrolled": "#b8b8b8", "Graduate": "#298c8c"}
BAR_COLOR = "#0072B2"
DROPOUT_COLOR = "#9b4141"

os.makedirs("figures", exist_ok=True)

ORDER = {
    "Target": OUTCOME_ORDER,
    "Gender": ["Female", "Male"],
    "Displaced": ["No", "Yes"],
    "Debtor": ["No", "Yes"],
    "Tuition_Up_To_Date": ["No", "Yes"],
    "Scholarship_Holder": ["No", "Yes"],
    "Daytime_Evening": ["Daytime", "Evening"],
    "Marital_Group": ["Single", "Not single"],
    "Age_Group": ["17-19", "20-24", "25-29", "30+"],
    "Admission_Grade_Band": ["Q1 (lowest)", "Q2", "Q3", "Q4 (highest)"],
    "Parent_Education": ["Basic", "Secondary", "Higher", "Unknown"],
    "Application_Order_Group": ["0-1", "2", "3+"],
    "Application_Mode_Group": [
        "General contingent",
        "Over 23 years old",
        "Transfer or change",
        "Prior diploma holder",
        "Special or other",
    ],
    "Passed_None_1st": ["No", "Yes"],
    "Passed_None_2nd": ["No", "Yes"],
}


def apply_order(df):
    df = df.copy()
    for col, cats in ORDER.items():
        if col in df.columns:
            df[col] = pd.Categorical(df[col], categories=cats, ordered=True)
    return df


df = pd.read_csv("student_dropout_cleaned.csv")

# Apply categorical ordering
df = apply_order(df)


# Select variables for E1
e1 = df[
    ["Course", "Course_Name", "Dropout_Binary"]
].copy()

# Remove missing values
e1 = e1.dropna(
    subset=["Course", "Dropout_Binary"]
).copy()

# Ensure Dropout_Binary is numeric
e1["Dropout_Binary"] = pd.to_numeric(
    e1["Dropout_Binary"],
    errors="coerce"
)

e1 = e1.dropna(
    subset=["Dropout_Binary"]
).copy()

# Check dataset
print("E1 dataset shape:", e1.shape)

print("\nNumber of courses:")
print(e1["Course"].nunique())

print("\nDropout distribution:")
print(e1["Dropout_Binary"].value_counts())



# Calculate dropout statistics by course
e1_summary = (
    e1.groupby(
        ["Course", "Course_Name"],
        observed=True
    )
    .agg(
        Total_Students=("Dropout_Binary", "count"),
        Dropouts=("Dropout_Binary", "sum"),
        Dropout_Rate=("Dropout_Binary", "mean")
    )
    .reset_index()
)

# Convert dropout rate into percentage
e1_summary["Dropout_Rate"] *= 100

# Sort courses by dropout rate
e1_summary = e1_summary.sort_values(
    "Dropout_Rate",
    ascending=False
)

print("Dropout rate by course:")
print(e1_summary.round(2).to_string(index=False))




# Highest dropout rate
highest_dropout = e1_summary.iloc[0]

# Lowest dropout rate
lowest_dropout = e1_summary.iloc[-1]

print("Course with the highest dropout rate:")
print(
    highest_dropout["Course_Name"],
    f"- {highest_dropout['Dropout_Rate']:.2f}%"
)

print("\nCourse with the lowest dropout rate:")
print(
    lowest_dropout["Course_Name"],
    f"- {lowest_dropout['Dropout_Rate']:.2f}%"
)



plt.figure(figsize=(11, 7))

plot_data = e1_summary.sort_values(
    "Dropout_Rate",
    ascending=True
)

sns.barplot(
    data=plot_data,
    x="Dropout_Rate",
    y="Course_Name",
    color=DROPOUT_COLOR
)

plt.title("Dropout Rate by Degree Course")
plt.xlabel("Dropout rate (%)")
plt.ylabel("Degree course")

plt.tight_layout()

'''plt.savefig(
    "figures/E1_dropout_rate_by_course.png",
    dpi=300,
    bbox_inches="tight"
)'''

plt.show()



# Create contingency table
contingency_e1 = pd.crosstab(
    e1["Course"],
    e1["Dropout_Binary"]
)

contingency_e1.columns = [
    "Non-Dropout",
    "Dropout"
]

print("Contingency table:")
print(contingency_e1)



# Chi-square test
chi2_e1, p_e1, dof_e1, expected_e1 = stats.chi2_contingency(
    contingency_e1
)

print("Chi-square test - E1")
print("---------------------")
print(f"Chi-square statistic: {chi2_e1:.4f}")
print(f"Degrees of freedom: {dof_e1}")
print(f"P-value: {p_e1:.10e}")

if p_e1 < 0.05:
    print("Result: Statistically significant association.")
else:
    print("Result: No statistically significant association.")

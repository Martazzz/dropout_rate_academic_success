import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

sns.set_theme(style="whitegrid")
plt.rcParams.update(
    {
        "figure.figsize": (9, 5),
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
    }
)

OUTCOME_ORDER = ["Dropout", "Enrolled", "Graduate"]
OUTCOME_PALETTE = {"Dropout": "#9b4141", "Enrolled": "#b8b8b8", "Graduate": "#298c8c"}
BAR_COLOR = "#0072B2"
DROPOUT_COLOR = "#9b4141"

os.makedirs("figures", exist_ok=True)

ORDER = {
    "Target": OUTCOME_ORDER,
    "Gender": ["Female", "Male"],
    "Displaced": ["No", "Yes"],
    "Debtor": ["No", "Yes"],
    "Tuition_Up_To_Date": ["No", "Yes"],
    "Scholarship_Holder": ["No", "Yes"],
    "Daytime_Evening": ["Daytime", "Evening"],
    "Marital_Group": ["Single", "Not single"],
    "Age_Group": ["17-19", "20-24", "25-29", "30+"],
    "Admission_Grade_Band": ["Q1 (lowest)", "Q2", "Q3", "Q4 (highest)"],
    "Parent_Education": ["Basic", "Secondary", "Higher", "Unknown"],
    "Application_Order_Group": ["0-1", "2", "3+"],
    "Application_Mode_Group": [
        "General contingent",
        "Over 23 years old",
        "Transfer or change",
        "Prior diploma holder",
        "Special or other",
    ],
    "Passed_None_1st": ["No", "Yes"],
    "Passed_None_2nd": ["No", "Yes"],
}


def apply_order(df):
    df = df.copy()
    for col, cats in ORDER.items():
        if col in df.columns:
            df[col] = pd.Categorical(df[col], categories=cats, ordered=True)
    return df


df = pd.read_csv("student_dropout_cleaned.csv")

# Apply categorical ordering
df = apply_order(df)



# Select variables for E2
e2 = df[
    ["Course", "Course_Name", "Dropout_Binary", "Approval_Rate_1st"]
].copy()

# Convert numerical variables
e2["Dropout_Binary"] = pd.to_numeric(
    e2["Dropout_Binary"],
    errors="coerce"
)

e2["Approval_Rate_1st"] = pd.to_numeric(
    e2["Approval_Rate_1st"],
    errors="coerce"
)

# Remove missing values
e2 = e2.dropna(
    subset=[
        "Course",
        "Dropout_Binary",
        "Approval_Rate_1st"
    ]
).copy()

print("E2 dataset shape:", e2.shape)

print("\nNumber of courses:")
print(e2["Course"].nunique())

print("\nApproval rate statistics:")
print(e2["Approval_Rate_1st"].describe())



# Aggregate data at course level
e2_summary = (
    e2.groupby(
        ["Course", "Course_Name"],
        observed=True
    )
    .agg(
        Total_Students=("Dropout_Binary", "count"),
        Dropouts=("Dropout_Binary", "sum"),
        Dropout_Rate=("Dropout_Binary", "mean"),
        Approval_Rate_1st=("Approval_Rate_1st", "mean")
    )
    .reset_index()
)

# Convert dropout rate to percentage
e2_summary["Dropout_Rate"] *= 100

# Sort by dropout rate
e2_summary = e2_summary.sort_values(
    "Dropout_Rate",
    ascending=False
)

print("Course-level statistics:")
print(e2_summary.round(2).to_string(index=False))



plt.figure(figsize=(9, 6))

sns.scatterplot(
    data=e2_summary,
    x="Approval_Rate_1st",
    y="Dropout_Rate",
    s=110,
    color=BAR_COLOR,
    edgecolor="black",
    alpha=0.8
)

# Add course labels
for _, row in e2_summary.iterrows():
    plt.annotate(
        row["Course_Name"],
        (
            row["Approval_Rate_1st"],
            row["Dropout_Rate"]
        ),
        xytext=(5, 5),
        textcoords="offset points",
        fontsize=8
    )

plt.title(
    "Course Dropout Rate vs First-Semester Approval Rate"
)
plt.xlabel("Average first-semester approval rate")
plt.ylabel("Dropout rate (%)")

plt.tight_layout()

'''plt.savefig(
    "figures/E2_dropout_vs_approval_rate.png",
    dpi=300,
    bbox_inches="tight"
)'''

plt.show()



# Spearman correlation
spearman_corr_e2, spearman_p_e2 = stats.spearmanr(
    e2_summary["Approval_Rate_1st"],
    e2_summary["Dropout_Rate"]
)

print("Spearman correlation - E2")
print("--------------------------")
print(f"Spearman correlation: {spearman_corr_e2:.4f}")
print(f"P-value: {spearman_p_e2:.10e}")

if spearman_p_e2 < 0.05:
    print("Result: Statistically significant correlation.")
else:
    print("Result: No statistically significant correlation.")



plt.figure(figsize=(9, 6))

sns.regplot(
    data=e2_summary,
    x="Approval_Rate_1st",
    y="Dropout_Rate",
    scatter_kws={
        "s": 110,
        "color": BAR_COLOR,
        "edgecolor": "black",
        "alpha": 0.8
    },
    line_kws={
        "color": DROPOUT_COLOR,
        "linewidth": 2
    },
    ci=None
)

for _, row in e2_summary.iterrows():
    plt.annotate(
        row["Course_Name"],
        (
            row["Approval_Rate_1st"],
            row["Dropout_Rate"]
        ),
        xytext=(5, 5),
        textcoords="offset points",
        fontsize=8
    )

plt.title(
    "Relationship Between Course Approval and Dropout Rates"
)
plt.xlabel("Average first-semester approval rate")
plt.ylabel("Dropout rate (%)")

plt.tight_layout()

'''plt.savefig(
    "figures/E2_dropout_vs_approval_regression.png",
    dpi=300,
    bbox_inches="tight"
)'''

plt.show()
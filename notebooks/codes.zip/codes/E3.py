import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

sns.set_theme(style="whitegrid")
plt.rcParams.update(
    {
        "figure.figsize": (9, 5),
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
    }
)

OUTCOME_ORDER = ["Dropout", "Enrolled", "Graduate"]
OUTCOME_PALETTE = {"Dropout": "#9b4141", "Enrolled": "#b8b8b8", "Graduate": "#298c8c"}
BAR_COLOR = "#0072B2"
DROPOUT_COLOR = "#9b4141"

os.makedirs("figures", exist_ok=True)

ORDER = {
    "Target": OUTCOME_ORDER,
    "Gender": ["Female", "Male"],
    "Displaced": ["No", "Yes"],
    "Debtor": ["No", "Yes"],
    "Tuition_Up_To_Date": ["No", "Yes"],
    "Scholarship_Holder": ["No", "Yes"],
    "Daytime_Evening": ["Daytime", "Evening"],
    "Marital_Group": ["Single", "Not single"],
    "Age_Group": ["17-19", "20-24", "25-29", "30+"],
    "Admission_Grade_Band": ["Q1 (lowest)", "Q2", "Q3", "Q4 (highest)"],
    "Parent_Education": ["Basic", "Secondary", "Higher", "Unknown"],
    "Application_Order_Group": ["0-1", "2", "3+"],
    "Application_Mode_Group": [
        "General contingent",
        "Over 23 years old",
        "Transfer or change",
        "Prior diploma holder",
        "Special or other",
    ],
    "Passed_None_1st": ["No", "Yes"],
    "Passed_None_2nd": ["No", "Yes"],
}


def apply_order(df):
    df = df.copy()
    for col, cats in ORDER.items():
        if col in df.columns:
            df[col] = pd.Categorical(df[col], categories=cats, ordered=True)
    return df


df = pd.read_csv("student_dropout_cleaned.csv")

# Apply categorical ordering
df = apply_order(df)



# Select variables for E3
e3 = df[
    ["Gender", "Course", "Course_Name", "Dropout_Binary"]
].copy()

# Remove missing values
e3 = e3.dropna(
    subset=["Gender", "Course", "Dropout_Binary"]
).copy()

# Ensure binary variable is numeric
e3["Dropout_Binary"] = pd.to_numeric(
    e3["Dropout_Binary"],
    errors="coerce"
)

e3 = e3.dropna(
    subset=["Dropout_Binary"]
).copy()

# Check distributions
print("E3 dataset shape:", e3.shape)

print("\nGender distribution:")
print(e3["Gender"].value_counts())

print("\nNumber of courses:")
print(e3["Course"].nunique())

print("\nDropout distribution:")
print(e3["Dropout_Binary"].value_counts())



# Count students by course and gender
e3_gender_counts = (
    e3.groupby(
        ["Course_Name", "Gender"],
        observed=True
    )
    .size()
    .unstack(fill_value=0)
)

print("Students by course and gender:")
print(e3_gender_counts)

# Minimum number of students per gender
MIN_STUDENTS = 30 

# Select courses with enough students of both genders
eligible_courses = e3_gender_counts[
    (e3_gender_counts["Female"] >= MIN_STUDENTS) &
    (e3_gender_counts["Male"] >= MIN_STUDENTS)
].index

e3_filtered = e3[
    e3["Course_Name"].isin(eligible_courses)
].copy()

print("\nEligible courses:")
print(list(eligible_courses))

print("\nFiltered dataset shape:")
print(e3_filtered.shape)



# Calculate dropout rate by course and gender
e3_summary = (
    e3_filtered.groupby( #Usare e3 se si vogliono le statistiche per tutti i corsi e non solo quelli con almeno 30 studenti per ogni genere
        ["Course_Name", "Gender"],
        observed=True
    )
    .agg(
        Total_Students=("Dropout_Binary", "count"),
        Dropouts=("Dropout_Binary", "sum"),
        Dropout_Rate=("Dropout_Binary", "mean")
    )
    .reset_index()
)

# Convert to percentage
e3_summary["Dropout_Rate"] *= 100

# Sort courses by overall dropout rate
course_order = (
    e3_summary.groupby("Course_Name")
    .apply(
        lambda x: np.average(
            x["Dropout_Rate"],
            weights=x["Total_Students"]
        ),
        include_groups=False
    )
    .sort_values()
    .index
    .tolist()
)

# Plot
plt.figure(figsize=(12, max(7, len(course_order) * 0.45)))

ax = sns.barplot(
    data=e3_summary,
    x="Dropout_Rate",
    y="Course_Name",
    hue="Gender",
    order=course_order,
    hue_order=["Female", "Male"],
    palette={
        "Female": "#CC79A7",
        "Male": "#0072B2"
    },
    orient="h"
)

# Add percentage labels
for container in ax.containers:
    ax.bar_label(
        container,
        fmt="%.1f%%",
        padding=3,
        fontsize=8
    )

plt.title("Dropout Rate by Course and Gender")
plt.xlabel("Dropout Rate (%)")
plt.ylabel("Degree Course")

plt.legend(title="Gender")

plt.tight_layout()

'''plt.savefig(
    "figures/E3_horizontal_dropout_by_gender.png",
    dpi=300,
    bbox_inches="tight"
)'''

plt.show()



# Chi-square test for each course
e3_results = []

for course in eligible_courses:

    course_data = e3_filtered[
        e3_filtered["Course_Name"] == course
    ]

    contingency = pd.crosstab(
        course_data["Gender"],
        course_data["Dropout_Binary"]
    )

    # Ensure both rows and columns are present
    contingency = contingency.reindex(
        index=["Female", "Male"],
        columns=[0, 1],
        fill_value=0
    )

    chi2, p_value, dof, expected = stats.chi2_contingency(
        contingency
    )

    e3_results.append({
        "Course": course,
        "Chi2": chi2,
        "P_value": p_value,
        "Min_Expected": expected.min()
    })

e3_results = pd.DataFrame(e3_results)

print("Chi-square results by course:")
print(e3_results.round(6).to_string(index=False))

print("\nStatistical interpretation:")

for _, row in e3_results.iterrows():

    course = row["Course"]

    # Use adjusted p-value if available
    p_value = row["P_value"]

    if pd.isna(p_value):
        print(f"\n{course}: Test not applicable.")
        continue

    print(f"\nCourse: {course}")
    print(f"Adjusted p-value: {p_value:.6f}")

    if p_value < 0.05:
        print(
            "RESULT: Statistically significant association "
            "between Gender and Dropout."
        )
    else:
        print(
            "RESULT: No statistically significant association "
            "between Gender and Dropout."
        )
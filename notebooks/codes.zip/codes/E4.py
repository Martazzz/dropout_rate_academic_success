import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

sns.set_theme(style="whitegrid")
plt.rcParams.update(
    {
        "figure.figsize": (9, 5),
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.labelsize": 12,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
    }
)

OUTCOME_ORDER = ["Dropout", "Enrolled", "Graduate"]
OUTCOME_PALETTE = {"Dropout": "#9b4141", "Enrolled": "#b8b8b8", "Graduate": "#298c8c"}
BAR_COLOR = "#0072B2"
DROPOUT_COLOR = "#9b4141"

os.makedirs("figures", exist_ok=True)

ORDER = {
    "Target": OUTCOME_ORDER,
    "Gender": ["Female", "Male"],
    "Displaced": ["No", "Yes"],
    "Debtor": ["No", "Yes"],
    "Tuition_Up_To_Date": ["No", "Yes"],
    "Scholarship_Holder": ["No", "Yes"],
    "Daytime_Evening": ["Daytime", "Evening"],
    "Marital_Group": ["Single", "Not single"],
    "Age_Group": ["17-19", "20-24", "25-29", "30+"],
    "Admission_Grade_Band": ["Q1 (lowest)", "Q2", "Q3", "Q4 (highest)"],
    "Parent_Education": ["Basic", "Secondary", "Higher", "Unknown"],
    "Application_Order_Group": ["0-1", "2", "3+"],
    "Application_Mode_Group": [
        "General contingent",
        "Over 23 years old",
        "Transfer or change",
        "Prior diploma holder",
        "Special or other",
    ],
    "Passed_None_1st": ["No", "Yes"],
    "Passed_None_2nd": ["No", "Yes"],
}


def apply_order(df):
    df = df.copy()
    for col, cats in ORDER.items():
        if col in df.columns:
            df[col] = pd.Categorical(df[col], categories=cats, ordered=True)
    return df


df = pd.read_csv("student_dropout_cleaned.csv")

# Apply categorical ordering
df = apply_order(df)

# Select variables
e4 = df[
    ["Course", "Course_Name", "Daytime_Evening", "Dropout_Binary"]
].copy()

# Keep the four relevant course variants
TARGET_COURSES = [
    "Social Service",
    "Social Service (evening)",
    "Management",
    "Management (evening)"
]

e4 = e4[
    e4["Course_Name"].isin(TARGET_COURSES)
].copy()

# Remove missing values
e4 = e4.dropna(
    subset=[
        "Course_Name",
        "Daytime_Evening",
        "Dropout_Binary"
    ]
).copy()

# Convert Dropout_Binary to numeric
e4["Dropout_Binary"] = pd.to_numeric(
    e4["Dropout_Binary"],
    errors="coerce"
)

e4 = e4.dropna(
    subset=["Dropout_Binary"]
).copy()

# Create common course category
e4["Course_Base"] = e4["Course_Name"].replace({
    "Social Service (evening)": "Social Service",
    "Management (evening)": "Management"
})

print("E4 dataset shape:", e4.shape)

print("\nCourses:")
print(e4["Course_Name"].value_counts())

print("\nAttendance mode:")
print(e4["Daytime_Evening"].value_counts())


e4_counts = pd.crosstab(
    e4["Course_Base"],
    e4["Daytime_Evening"]
).reindex(
    index=["Social Service", "Management"],
    columns=["Daytime", "Evening"],
    fill_value=0
)

print("Students by course and attendance mode:")
print(e4_counts)

e4_summary = (
    e4.groupby(
        ["Course_Base", "Daytime_Evening"],
        observed=True
    )
    .agg(
        Total_Students=("Dropout_Binary", "count"),
        Dropouts=("Dropout_Binary", "sum"),
        Dropout_Rate=("Dropout_Binary", "mean")
    )
    .reset_index()
)

# Convert to percentage
e4_summary["Dropout_Rate"] *= 100

print("Dropout rate by course and attendance mode:")
print(e4_summary.round(2).to_string(index=False))

plt.figure(figsize=(10, 6))

sns.barplot(
    data=e4_summary,
    x="Course_Base",
    y="Dropout_Rate",
    hue="Daytime_Evening",
    hue_order=["Daytime", "Evening"],
    palette={
        "Daytime": "#0072B2",
        "Evening": "#E69F00"
    },
    errorbar=None
)

plt.title("Dropout Rate by Course and Attendance Mode")
plt.xlabel("Degree course")
plt.ylabel("Dropout rate (%)")

plt.legend(title="Attendance mode")

plt.tight_layout()

'''plt.savefig(
    "figures/E4_dropout_rate_by_course_and_attendance.png",
    dpi=300,
    bbox_inches="tight"
)'''

plt.show()

e4_results = []

for course in ["Social Service", "Management"]:

    course_data = e4[
        e4["Course_Base"] == course
    ]

    contingency = pd.crosstab(
        course_data["Daytime_Evening"],
        course_data["Dropout_Binary"]
    ).reindex(
        index=["Daytime", "Evening"],
        columns=[0, 1],
        fill_value=0
    )

    print(f"\nCourse: {course}")
    print(contingency)

    # Check for empty rows or columns
    if (
        (contingency.sum(axis=1) == 0).any()
        or (contingency.sum(axis=0) == 0).any()
    ):
        print("Test cannot be performed: empty row or column.")

        e4_results.append({
            "Course": course,
            "Chi2": np.nan,
            "P_value": np.nan,
            "Min_Expected": np.nan,
            "Test": "Not applicable"
        })

        continue

    # Chi-square test
    chi2, p_value, dof, expected = stats.chi2_contingency(
        contingency
    )

    e4_results.append({
        "Course": course,
        "Chi2": chi2,
        "P_value": p_value,
        "Min_Expected": expected.min(),
        "Test": "Chi-square"
    })

e4_results = pd.DataFrame(e4_results)

print("\nChi-square results:")
print(e4_results.round(6).to_string(index=False))




print("\nStatistical interpretation")

for _, row in e4_results.iterrows():

    course = row["Course"]

    p_value = row["P_value"]

    if pd.isna(p_value):
        print(f"\n{course}: Test not applicable.")
        continue

    print(f"\nCourse: {course}")
    print(f"Adjusted p-value: {p_value:.6f}")

    if p_value < 0.05:
        print(
            "RESULT: Statistically significant association "
            "between Attendance Mode and Dropout."
        )
    else:
        print(
            "RESULT: No statistically significant association "
            "between Attendance Mode and Dropout."
        )
